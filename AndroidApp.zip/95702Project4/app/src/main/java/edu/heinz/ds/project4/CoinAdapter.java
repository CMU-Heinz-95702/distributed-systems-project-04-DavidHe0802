package edu.heinz.ds.project4;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CoinAdapter extends RecyclerView.Adapter<CoinAdapter.CoinViewHolder> {
    private List<Coin> coins = new ArrayList<>();
    private final OnCoinClickListener listener;
    private final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.US);

    public interface OnCoinClickListener {
        void onCoinClick(Coin coin);
    }

    public CoinAdapter(OnCoinClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public CoinViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_coin, parent, false);
        return new CoinViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CoinViewHolder holder, int position) {
        holder.bind(coins.get(position));
    }

    @Override
    public int getItemCount() {
        return coins.size();
    }

    public void updateData(List<Coin> newCoins) {
        coins = newCoins;
        notifyDataSetChanged();
    }

    class CoinViewHolder extends RecyclerView.ViewHolder {
        private final ImageView coinImage;
        private final TextView coinName;
        private final TextView coinSymbol;
        private final TextView price;
        private final TextView priceChangePercent;

        public CoinViewHolder(@NonNull View itemView) {
            super(itemView);
            coinImage = itemView.findViewById(R.id.coinImage);
            coinName = itemView.findViewById(R.id.coinName);
            coinSymbol = itemView.findViewById(R.id.coinSymbol);
            price = itemView.findViewById(R.id.price);
            priceChangePercent = itemView.findViewById(R.id.priceChangePercent);

            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    listener.onCoinClick(coins.get(position));
                }
            });
        }

        void bind(Coin coin) {
            coinName.setText(coin.getName());
            coinSymbol.setText(coin.getSymbol().toUpperCase());
            price.setText(currencyFormat.format(coin.getCurrentPrice()));

            double priceChange = coin.getPriceChangePercentage24h();
            String priceChangeText = String.format("%.2f%%", priceChange);
            priceChangePercent.setTextColor(priceChange >= 0 ?
                    ContextCompat.getColor(itemView.getContext(), R.color.price_up) :
                    ContextCompat.getColor(itemView.getContext(), R.color.price_down));
            priceChangePercent.setText(priceChangeText);

            // Load image using Glide
            Glide.with(itemView.getContext())
                    .load(coin.getImageUrl())
                    .placeholder(R.drawable.placeholder_coin)
                    .into(coinImage);
        }
    }
}