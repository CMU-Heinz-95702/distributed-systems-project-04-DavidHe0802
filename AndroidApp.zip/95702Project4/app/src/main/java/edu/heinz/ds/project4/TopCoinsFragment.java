package edu.heinz.ds.project4;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.snackbar.Snackbar;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.google.gson.stream.JsonReader;
import java.io.StringReader;
import com.google.gson.Gson;

public class TopCoinsFragment extends Fragment implements CoinAdapter.OnCoinClickListener {
    private CoinAdapter adapter;
    private SwipeRefreshLayout swipeRefreshLayout;
    private final Gson gson = new Gson();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_coin_list, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.recyclerView);
        swipeRefreshLayout = view.findViewById(R.id.swipeRefresh);
        adapter = new CoinAdapter(this);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        // Add item decoration for spacing
        recyclerView.addItemDecoration(new DividerItemDecoration(requireContext(),
                DividerItemDecoration.VERTICAL));

        swipeRefreshLayout.setOnRefreshListener(this::loadTopCoins);

        loadTopCoins();
        return view;
    }

    private String getDeviceIpAddress() {
        try {
            for (NetworkInterface networkInterface : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                for (InetAddress address : Collections.list(networkInterface.getInetAddresses())) {
                    if (!address.isLoopbackAddress()) {
                        String hostAddress = address.getHostAddress();
                        boolean isIPv4 = hostAddress.indexOf(':') < 0;
                        if (isIPv4) {
                            return hostAddress;
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private void loadTopCoins() {
        String deviceIpAddress = getDeviceIpAddress();
        if (deviceIpAddress != null) {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url("http://10.0.2.2:8080/crypto_api_war_exploded/api/top-coins")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(@NonNull Call call, @NonNull IOException e) {
                    requireActivity().runOnUiThread(() -> {
                        swipeRefreshLayout.setRefreshing(false);
                        showError("Failed to load top coins: " + e.getMessage());
                    });
                }

                @Override
                public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                    String responseData = response.body().string();
                    requireActivity().runOnUiThread(() -> {
                        swipeRefreshLayout.setRefreshing(false);
                        try {
                            // First try standard JSON parsing
                            try {
                                JSONObject json = new JSONObject(responseData);
                                if (json.getBoolean("success")) {
                                    JSONArray data = json.getJSONArray("data");
                                    List<Coin> coins = parseCoins(data);
                                    adapter.updateData(coins);
                                } else {
                                    showError(json.getString("message"));
                                }
                            } catch (JSONException e) {
                                // If standard parsing fails, try with lenient parsing
                                JsonReader reader = new JsonReader(new StringReader(responseData));
                                reader.setLenient(true);
                                try {
                                    ApiResponse apiResponse = gson.fromJson(reader, ApiResponse.class);
                                    if (apiResponse != null && apiResponse.isSuccess()) {
                                        List<Coin> coins = apiResponse.getData();
                                        adapter.updateData(coins);
                                    } else {
                                        showError("Invalid response format");
                                    }
                                } catch (Exception e2) {
                                    showError("Failed to parse response: " + e2.getMessage());
                                }
                            }
                        } catch (Exception e) {
                            showError("Failed to process response: " + e.getMessage());
                        }
                    });
                }
            });
        } else {
            // Handle the case where the device IP address could not be retrieved
            showError("Failed to retrieve device IP address");
        }
    }

    private static class ApiResponse {
        private boolean success;
        private List<Coin> data;

        public boolean isSuccess() {
            return success;
        }

        public List<Coin> getData() {
            return data;
        }
    }


    private List<Coin> parseCoins(JSONArray jsonArray) throws JSONException {
        List<Coin> coins = new ArrayList<>();
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject coinJson = jsonArray.getJSONObject(i);
            Coin coin = new Coin(
                    coinJson.getString("id"),
                    coinJson.getString("name"),
                    coinJson.getString("symbol"),
                    coinJson.getString("image"),
                    coinJson.getDouble("current_price"),
                    coinJson.getDouble("market_cap"),
                    coinJson.getDouble("price_change_percentage_24h"),
                    coinJson.getDouble("total_volume"),
                    coinJson.getInt("market_cap_rank")
            );
            coins.add(coin);
        }
        return coins;
    }

    private void showError(String message) {
        Snackbar.make(requireView(), message, Snackbar.LENGTH_LONG)
                .setAction("Retry", v -> loadTopCoins())
                .show();
    }

    @Override
    public void onCoinClick(Coin coin) {
        Intent intent = new Intent(getActivity(), CoinDetailActivity.class);
        intent.putExtra("coinId", coin.getId());
        startActivity(intent);
    }
}