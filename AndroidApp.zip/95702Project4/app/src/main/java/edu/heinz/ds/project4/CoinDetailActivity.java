package edu.heinz.ds.project4;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.bumptech.glide.Glide;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.snackbar.Snackbar;
import okhttp3.*;

import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Locale;
import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import java.io.StringReader;

public class CoinDetailActivity extends AppCompatActivity {
    private ImageView coinImage;
    private TextView priceText;
    private TextView marketCapText;
    private TextView volumeText;
    private TextView priceChangeText;
    private TextView descriptionText;
    private View progressBar;
    private final Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coin_detail);

        // Initialize views
        Toolbar toolbar = findViewById(R.id.detailToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        coinImage = findViewById(R.id.coinDetailImage);
        priceText = findViewById(R.id.priceText);
        marketCapText = findViewById(R.id.marketCapText);
        volumeText = findViewById(R.id.volumeText);
        priceChangeText = findViewById(R.id.priceChangeText);
        descriptionText = findViewById(R.id.descriptionText);
        progressBar = findViewById(R.id.progressBar);

        String coinId = getIntent().getStringExtra("coinId");
        if (coinId != null) {
            loadCoinDetails(coinId);
        }
    }

    private void loadCoinDetails(String coinId) {
        progressBar.setVisibility(View.VISIBLE);

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url("http://10.0.2.2:8080/crypto_api_war_exploded/api/coin/" + coinId)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    showError("Failed to load coin details");
                    finish();
                });
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                String responseData = response.body().string();
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    try {
                        // First try standard JSON parsing
                        try {
                            JSONObject json = new JSONObject(responseData);
                            if (json.getBoolean("success")) {
                                updateUI(json.getJSONObject("data"));
                            } else {
                                showError(getString(R.string.coin_not_found));
                                finish();
                            }
                        } catch (JSONException e) {
                            // If standard parsing fails, try with lenient parsing
                            JsonReader reader = new JsonReader(new StringReader(responseData));
                            reader.setLenient(true);
                            try {
                                CoinDetailResponse detailResponse = gson.fromJson(reader, CoinDetailResponse.class);
                                if (detailResponse != null && detailResponse.isSuccess()) {
                                    updateUI(new JSONObject(gson.toJson(detailResponse.getData())));
                                } else {
                                    showError("Invalid response format");
                                }
                            } catch (Exception e2) {
                                showError("Failed to parse response: " + e2.getMessage());
                            }
                        }
                    } catch (Exception e) {
                        showError("Failed to process response: " + e.getMessage());
                    }
                });
            }
        });
    }

    private static class CoinDetailResponse {
        private boolean success;
        private JSONObject data;

        public boolean isSuccess() {
            return success;
        }

        public JSONObject getData() {
            return data;
        }
    }

    private void updateUI(JSONObject data) throws Exception {
        CollapsingToolbarLayout collapsingToolbar = findViewById(R.id.collapsingToolbar);
        collapsingToolbar.setTitle(data.getString("name"));

        // Load image
        Glide.with(this)
                .load(data.getJSONObject("image").getString("large"))
                .into(coinImage);

        // Format currency values
        NumberFormat format = NumberFormat.getCurrencyInstance(Locale.US);
        double price = data.getJSONObject("market_data")
                .getJSONObject("current_price").getDouble("usd");
        priceText.setText(format.format(price));

        // Set other details
        marketCapText.setText(String.format("Market Cap: %s",
                format.format(data.getJSONObject("market_data")
                        .getJSONObject("market_cap").getDouble("usd"))));

        volumeText.setText(String.format("24h Volume: %s",
                format.format(data.getJSONObject("market_data")
                        .getJSONObject("total_volume").getDouble("usd"))));

        double priceChange = data.getJSONObject("market_data")
                .getDouble("price_change_percentage_24h");
        String priceChangeStr = String.format(Locale.US, "24h Change: %.2f%%", priceChange);
        priceChangeText.setText(priceChangeStr);
        priceChangeText.setTextColor(getColor(priceChange >= 0 ? R.color.price_up : R.color.price_down));

        // Set description if available
        if (data.has("description") && !data.getJSONObject("description")
                .getString("en").isEmpty()) {
            descriptionText.setText(data.getJSONObject("description").getString("en"));
        } else {
            descriptionText.setVisibility(View.GONE);
        }
    }

    private void showError(String message) {
        Snackbar.make(findViewById(android.R.id.content),
                message, Snackbar.LENGTH_LONG).show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}