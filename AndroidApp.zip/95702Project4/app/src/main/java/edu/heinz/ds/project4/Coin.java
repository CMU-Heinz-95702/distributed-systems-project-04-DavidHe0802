package edu.heinz.ds.project4;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.core.content.ContextCompat;
import java.text.NumberFormat;
import java.util.Locale;

public class Coin implements Parcelable {
    private String id;
    private String name;
    private String symbol;
    private String imageUrl;
    private double currentPrice;
    private double marketCap;
    private double priceChangePercentage24h;
    private double totalVolume;
    private int marketCapRank;
    private String description;  // For coin details

    // Constructor for list view
    public Coin(String id, String name, String symbol, String imageUrl,
                double currentPrice, double marketCap,
                double priceChangePercentage24h, double totalVolume,
                int marketCapRank) {
        this.id = id;
        this.name = name;
        this.symbol = symbol;
        this.imageUrl = imageUrl;
        this.currentPrice = currentPrice;
        this.marketCap = marketCap;
        this.priceChangePercentage24h = priceChangePercentage24h;
        this.totalVolume = totalVolume;
        this.marketCapRank = marketCapRank;
    }

    // Parcelable implementation for passing between activities
    protected Coin(Parcel in) {
        id = in.readString();
        name = in.readString();
        symbol = in.readString();
        imageUrl = in.readString();
        currentPrice = in.readDouble();
        marketCap = in.readDouble();
        priceChangePercentage24h = in.readDouble();
        totalVolume = in.readDouble();
        marketCapRank = in.readInt();
        description = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(name);
        dest.writeString(symbol);
        dest.writeString(imageUrl);
        dest.writeDouble(currentPrice);
        dest.writeDouble(marketCap);
        dest.writeDouble(priceChangePercentage24h);
        dest.writeDouble(totalVolume);
        dest.writeInt(marketCapRank);
        dest.writeString(description);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Coin> CREATOR = new Creator<Coin>() {
        @Override
        public Coin createFromParcel(Parcel in) {
            return new Coin(in);
        }

        @Override
        public Coin[] newArray(int size) {
            return new Coin[size];
        }
    };

    // Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public String getSymbol() { return symbol; }
    public String getImageUrl() { return imageUrl; }
    public double getCurrentPrice() { return currentPrice; }
    public double getMarketCap() { return marketCap; }
    public double getPriceChangePercentage24h() { return priceChangePercentage24h; }
    public double getTotalVolume() { return totalVolume; }
    public int getMarketCapRank() { return marketCapRank; }
    public String getDescription() { return description; }

    // Setters
    public void setDescription(String description) { this.description = description; }

    // Helper methods
    public String getFormattedPrice() {
        NumberFormat format = NumberFormat.getCurrencyInstance(Locale.US);
        return format.format(currentPrice);
    }

    public String getFormattedMarketCap() {
        if (marketCap >= 1_000_000_000_000L) { // Trillion
            return String.format(Locale.US, "$%.2fT", marketCap / 1_000_000_000_000.0);
        } else if (marketCap >= 1_000_000_000) { // Billion
            return String.format(Locale.US, "$%.2fB", marketCap / 1_000_000_000.0);
        } else if (marketCap >= 1_000_000) { // Million
            return String.format(Locale.US, "$%.2fM", marketCap / 1_000_000.0);
        }
        return NumberFormat.getCurrencyInstance(Locale.US).format(marketCap);
    }

    public String getFormattedPriceChange() {
        return String.format(Locale.US, "%.2f%%", priceChangePercentage24h);
    }

    public int getPriceChangeColor(Context context) {
        return priceChangePercentage24h >= 0 ?
                ContextCompat.getColor(context, R.color.price_up) :
                ContextCompat.getColor(context, R.color.price_down);
    }
}