package edu.heinz.ds.project4;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.snackbar.Snackbar;
import okhttp3.*;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import java.io.StringReader;

public class TrendingCoinsFragment extends Fragment implements CoinAdapter.OnCoinClickListener {
    private CoinAdapter adapter;
    private SwipeRefreshLayout swipeRefreshLayout;
    private final Gson gson = new Gson();
    private View rootView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_coin_list, container, false);

        RecyclerView recyclerView = rootView.findViewById(R.id.recyclerView);
        swipeRefreshLayout = rootView.findViewById(R.id.swipeRefresh);
        adapter = new CoinAdapter(this);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);
        recyclerView.addItemDecoration(new DividerItemDecoration(requireContext(),
                DividerItemDecoration.VERTICAL));

        swipeRefreshLayout.setOnRefreshListener(this::loadTrendingCoins);

        loadTrendingCoins();
        return rootView;
    }

    private void loadTrendingCoins() {
        if (!isAdded()) {
            return; // Don't proceed if fragment is not attached
        }

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url("http://10.0.2.2:8080/crypto_api_war_exploded/api/trending")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                if (isAdded()) {
                    requireActivity().runOnUiThread(() -> {
                        swipeRefreshLayout.setRefreshing(false);
                        showError("Failed to load trending coins: " + e.getMessage());
                    });
                }
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (!isAdded()) {
                    return; // Don't proceed if fragment is not attached
                }

                final String responseData = response.body().string();
                requireActivity().runOnUiThread(() -> {
                    swipeRefreshLayout.setRefreshing(false);
                    try {
                        processResponse(responseData);
                    } catch (Exception e) {
                        showError("Failed to process response: " + e.getMessage());
                    }
                });
            }
        });
    }

    private void processResponse(String responseData) {
        try {
            JSONObject json = new JSONObject(responseData);
            if (json.getBoolean("success")) {
                JSONArray data = json.getJSONArray("data");
                List<Coin> coins = parseCoins(data);
                adapter.updateData(coins);
            } else {
                showError(json.optString("message", "Unknown error occurred"));
            }
        } catch (JSONException e) {
            // Try lenient parsing as fallback
            try {
                JsonReader reader = new JsonReader(new StringReader(responseData));
                reader.setLenient(true);
                ApiResponse apiResponse = gson.fromJson(reader, ApiResponse.class);
                if (apiResponse != null && apiResponse.isSuccess()) {
                    List<Coin> coins = apiResponse.getData();
                    if (coins != null && !coins.isEmpty()) {
                        adapter.updateData(coins);
                    } else {
                        showError("No coin data available");
                    }
                } else {
                    showError("Invalid response format");
                }
            } catch (Exception e2) {
                showError("Failed to parse response");
            }
        }
    }

    private List<Coin> parseCoins(JSONArray jsonArray) throws JSONException {
        List<Coin> coins = new ArrayList<>();
        for (int i = 0; i < jsonArray.length(); i++) {
            try {
                JSONObject item = jsonArray.getJSONObject(i)
                        .getJSONObject("item");

                // Get basic coin info from the item object directly
                String id = item.optString("id", "");
                String name = item.optString("name", "");
                String symbol = item.optString("symbol", "");
                String image = item.optString("thumb", ""); // Using thumb as image URL
                int marketCapRank = item.optInt("market_cap_rank", 0);

                // Get price data from the nested data object
                JSONObject data = item.getJSONObject("data");

                // Parse price and market data
                double price = parsePrice(data.optString("price", "0"));
                double marketCap = parsePrice(data.optString("market_cap", "0"));
                double totalVolume = parsePrice(data.optString("total_volume", "0"));

                // Parse price change percentage
                double priceChange = 0.0;
                JSONObject priceChangeObj = data.optJSONObject("price_change_percentage_24h");
                if (priceChangeObj != null) {
                    priceChange = priceChangeObj.optDouble("usd", 0.0);
                }

                Coin coin = new Coin(
                        id,
                        name,
                        symbol.toUpperCase(), // Convert symbol to uppercase for consistency
                        image,
                        price,
                        marketCap,
                        priceChange,
                        totalVolume,
                        marketCapRank
                );
                coins.add(coin);
            } catch (Exception e) {
                // Skip this coin if there's an error parsing it
                continue;
            }
        }
        return coins;
    }

    private double parsePrice(String priceStr) {
        try {
            // Remove $ and , from string, then parse to double
            return Double.parseDouble(priceStr.replace("$", "").replace(",", "").trim());
        } catch (NumberFormatException e) {
            try {
                // If the price is already a number without $ formatting
                return Double.parseDouble(priceStr);
            } catch (NumberFormatException e2) {
                return 0.0;
            }
        }
    }


    private void showError(String message) {
        if (rootView != null && isAdded()) {
            Snackbar.make(rootView, message, Snackbar.LENGTH_LONG)
                    .setAction("Retry", v -> loadTrendingCoins())
                    .show();
        }
    }

    @Override
    public void onCoinClick(Coin coin) {
        if (isAdded() && getActivity() != null) {
            Intent intent = new Intent(getActivity(), CoinDetailActivity.class);
            intent.putExtra("coinId", coin.getId());
            startActivity(intent);
        }
    }

    private static class ApiResponse {
        private boolean success;
        private List<Coin> data;

        public boolean isSuccess() {
            return success;
        }

        public List<Coin> getData() {
            return data;
        }
    }
}